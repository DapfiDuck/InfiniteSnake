package main;

import javax.swing.JOptionPane;

import engine.Apple;
import engine.Snake;
import gfx.Canvas;

public class InfiniteSnake {

	public static void main(String[] args) {

		int next = 0;

		int cx = 15, cy = 9;

		do {

			Apple a = new Apple(3, 4);
			Snake s = new Snake(cx, cy);
			Canvas c = new Canvas(s, a, cx, cy);

			c.start(s, c);

			next = JOptionPane.showConfirmDialog(null, "Next Round", "" , 0);

		} while (next == 0);
		
		JOptionPane.showMessageDialog(null, "Good Bye");

	}

}
