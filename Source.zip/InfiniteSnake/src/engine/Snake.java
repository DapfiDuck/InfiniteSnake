package engine;

import java.util.ArrayList;

public class Snake {
		
	int cx, cy;
	
	int score = 0;
	
	ArrayList<Cell> cells = new ArrayList<Cell>();
	
	public Snake(int cx, int cy) {
		
		this.cx = cx;
		this.cy = cy;
	

		int[] pos = {5,4};

		
		
		for(int i=0; i<5; i++){
			cells.add(new Cell(pos));
		}
		
		
	}
	
	public void add() {
		cells.add(new Cell(cells.get(cells.size()-1).getpos()));
		score++;
	}
	
	
	public void move(int x, int y) {
		
		
		for(int i = cells.size()-1; i>0; i--){
						
			int pos[] = new int[2];
			
			pos[0] = cells.get(i-1).getpos()[0];
			pos[1] = cells.get(i-1).getpos()[1];
			
			cells.get(i).setpos(pos);
			
			
		}
		
		cells.get(0).move(x, y, cx, cy);
		
		
	}
	
	public boolean testColision() {
		
		for(int i = 1; i<cells.size(); i++){
			
//			System.out.println(i + ": " + cells.get(i).getpos()[0] + " - " + cells.get(i).getpos()[1] + "\t 0: " + cells.get(0).getpos()[0] + " - " + cells.get(0).getpos()[1]);
			
			if(cells.get(i).getpos()[0]==cells.get(0).getpos()[0]&&cells.get(i).getpos()[1]==cells.get(0).getpos()[1]){

//				System.out.println("Collision " + i);
				return true;
			}
		}
		
		return false;
		
	}
	
	public boolean testEat(int pos[]) {
		return (pos[0] == cells.get(0).getpos()[0]&&pos[1]==cells.get(0).getpos()[1]);
	}
	

	public int getScore() {
		return score;
	}
	
	public ArrayList<Cell> getCells(){
		return cells;
	}
}
