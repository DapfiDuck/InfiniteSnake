package engine;

import java.util.Random;

public class Apple {

	int pos[];
	boolean ins = false;

	public Apple(int pos[]) {
		this.pos = pos;
	}

	public Apple(int x, int y) {
		pos = new int[2];

		this.pos[0] = x;
		this.pos[1] = y;
	}

	public void newPos(int cx, int cy, Snake s) {

		Random r = new Random();
		do {
			
			ins = false;

			this.pos[0] = r.nextInt(cx);
			this.pos[1] = r.nextInt(cy);

			System.out.println("Repositionong Apple to " + pos[0] + " - " + pos[1]);

			for (int i = 0; i < s.getCells().size() && !ins; i++) {
				ins = (s.getCells().get(i).getpos()[0] == pos[0] && s.getCells().get(i).getpos()[1] == pos[1]);
			}

		} while (ins);

	}

	public int[] getPos() {
		return pos;
	}

	public void setPos(int[] pos) {
		this.pos = pos;
	}

}
