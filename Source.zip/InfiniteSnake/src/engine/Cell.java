package engine;

public class Cell {
	
	int pos[] = new int[2];
	
	public Cell(int p[]){
		pos = p;
	}
	
	public void setpos(int p[]){
		pos = p;
	}
	
	public int[] getpos(){
		return pos;
	}
	
	public void move(int x, int y, int cx, int cy){
		
		pos[0] = (pos[0]+x)%(cx);
		pos[1] = (pos[1]+y)%(cy);
		
		if(pos[0]<0){
			pos[0] = cx-1;
		}
		
		if(pos[1]<0){
			pos[1] = cy-1;
		}
			
		
//		System.out.println(pos[0] + " - " + pos[1]);
	}

}
