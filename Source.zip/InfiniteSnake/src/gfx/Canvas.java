package gfx;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import engine.Apple;
import engine.Cell;
import engine.Snake;

@SuppressWarnings("serial")
public class Canvas extends JFrame implements KeyListener {

	boolean movable = true;

	ArrayList<Character> events = new ArrayList<Character>();

	int mx = 1;
	int my = 0;

	int s = 100;
	int sx, sy;
	int cx, cy;

	Snake snake;
	Apple apple;

	Image offImg;
	Graphics offg;

	public Canvas(Snake snake, Apple a, int cx, int cy) {

		this.snake = snake;
		this.apple = a;

		sx = cx * s;
		sy = cy * s;

		this.cx = cx;
		this.cy = cy;

		this.setSize(sx, sy);
		this.setUndecorated(true);
		this.setDefaultCloseOperation(3);
		this.setFocusable(true);
		this.addKeyListener(this);
		this.setVisible(true);

	}

	public Image generate() {

		offImg = createImage(sx, sy);

		offg = offImg.getGraphics();

		offg.setColor(Color.BLACK);
		offg.fillRect(0, 0, sx, sy);

		offg.setColor(Color.white);

		for (int x = 0; x < sx / s; x++) {
			for (int y = 0; y < sy / s; y++) {
				offg.drawRect(x * s, y * s, s - 1, s - 1);
			}
		}

		ArrayList<Cell> cells = snake.getCells();

		offg.setColor(new Color(150, 150, 150));

		for (int i = 0; i < cells.size()-1; i++) {

			offg.fillRect(cells.get(i).getpos()[0] * s, cells.get(i).getpos()[1] * s, s, s);

			offg.setColor(Color.white);

		}
		
		offg.setColor(new Color(200, 200, 200));
		offg.fillRect(cells.get(cells.size()-1).getpos()[0] * s, cells.get(cells.size()-1).getpos()[1] * s, s, s);

		offg.setColor(Color.red);
		offg.fillRect(apple.getPos()[0] * s, apple.getPos()[1] * s, s, s);

		return offImg;

	}

	public void paint(Graphics g) {

		g.drawImage(generate(), 0, 0, this);

	}

	public void start(Snake s, Canvas c) {

		boolean running = true;
		int t = 150;

		while (running) {

			getmove();
			s.move(mx, my);

			if (s.testEat(apple.getPos())) {
				s.add();
				apple.newPos(cx, cy, s);
			}

			if (s.testColision()) {
				running = false;
			}

			try {
				Thread.sleep(t);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			c.repaint();
		}

		c.dispose();

		JOptionPane.showMessageDialog(null, "Score: " + s.getScore());

	}

	public void getmove() {
		if (events.size() > 0) {
			// System.out.println(events.get(0));

			if (events.get(0) == 'w' && my != 1) {
				my = -1;
				mx = 0;
				movable = false;
			} else if (events.get(0) == 's' && my != -1) {
				my = 1;
				mx = 0;
				movable = false;
			} else if (events.get(0) == 'a' && mx != 1) {
				mx = -1;
				my = 0;
				movable = false;
			} else if (events.get(0) == 'd' && mx != -1) {
				mx = 1;
				my = 0;
				movable = false;
			}

			events.remove(0);
		}
	}

	@Override
	public void keyPressed(KeyEvent k) {

		events.add(k.getKeyChar());

	}

	@Override
	public void keyReleased(KeyEvent k) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent k) {
		// TODO Auto-generated method stub

	}

}
